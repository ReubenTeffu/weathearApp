# weather-app
this is a simple well organized weather web application that uses HTML CSS and venilla Javascript, im using Jquery to 
add the preoader animation and swiperJS library to creat the forecast slider, everything is well commented so 
its eady to follow it line by line .

Open Weather app folder and click onhte idex file to run the application.